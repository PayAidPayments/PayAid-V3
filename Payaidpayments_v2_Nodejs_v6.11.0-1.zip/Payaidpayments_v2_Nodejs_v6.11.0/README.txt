1. Open the command prompt Navigate to "PayaidPayments" directory  execute the following  commands one by one
	a. npm install express
	b. npm install jade
	c. npm intall body-parser
2. Replace the SALT and API_KEY in app.js file .
3. Run the command "node app.js" and hit the link "http://localhost:8888/" in the browser you will get the PayaidPayments form .
4. Fill all mandatory fileds and select mode of transaction LIVE or TEST and submit the form you will redirect to payment gatewaye.